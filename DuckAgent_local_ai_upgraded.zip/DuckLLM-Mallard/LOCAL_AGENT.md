# DuckLLM — Local Agent additions

## Computer commands

The desktop app now has a deterministic local-command layer. Commands are executed directly by Python; the model is not asked to generate shell commands.

Examples:

- `создай файл с именем test.txt`
- `создай папку с именем Projects`
- `создай zip backup.zip из Projects`
- `открой калькулятор`
- `открой notepad`
- `громкость 35`
- `яркость 70`
- `выключи компьютер` (asks for confirmation)
- `перезагрузи компьютер` (asks for confirmation)

English aliases are supported for the same operations.

### Safety

- File/folder creation defaults to the application directory.
- Existing files are not overwritten by the "create file" command.
- Shutdown/restart always asks for confirmation.
- Commands can be disabled from Settings → AI.
- No `shell=True` is used for application launching or system power commands.

Windows volume control uses `pycaw` + `comtypes`. The build script installs these dependencies.

## Personalization / Settings

The ⚙ button opens:

- system/personality prompt
- temperature
- maximum output tokens
- local-command permission
- local customization/training examples

The Customization tab stores `training_data.jsonl`. These examples are a local customization dataset; they do **not** modify GGUF weights.

## Export / import

"Export profile…" creates a ZIP containing:

- `duckllm_settings.json`
- `training_data.jsonl`
- `duckllm_chat.json`
- `DuckLLM.gguf` when a local model is present next to the application

This is intended as a portable personal configuration/profile. A real weight-level fine-tune still requires a separate training/fine-tuning workflow and a sufficiently large model/dataset.
